module SomeModule (
    demoFunc      -- IO()
    ) where

demoFunc :: IO ()
demoFunc = putStr "demoFunc: Just for a test."
